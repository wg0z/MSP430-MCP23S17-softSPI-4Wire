/*
 * MCP23S17_primitives.c
 *
 *  Created on: Jun 30, 2017
 *      Author: JJH
 */

#include <msp430.h>
#include "MCP23S17_named_numbers.h"
#include "MCP23S17_config.h"


#define NORESET     RESET_OUTPORT |= RESET_BIT_MASK
#define RESET_L     RESET_OUTPORT &= ~RESET_BIT_MASK

#define DESELECT    CS_OUTPORT |= CS_BIT_MASK
#define SELECT_L    CS_OUTPORT &= ~CS_BIT_MASK

#define MOSI_HI     MOSI_OUTPORT |= MOSI_BIT_MASK
#define MOSI_LO     MOSI_OUTPORT &= ~MOSI_BIT_MASK

#define CLK_HI      CLK_OUTPORT |= CLK_BIT_MASK
#define CLK_LO      CLK_OUTPORT &= ~CLK_BIT_MASK





static unsigned xcvByte( unsigned Byte )
{
    // function to send 8 bits via MOSI / rcv 8 bits via MISO
    // usually only the bits sent or rcvd are of any real interest

    unsigned Retval;
    unsigned Mask = 0x80;

    do
    {
        Retval = Retval << 1;
        // set up MOSI
        if (Mask & Byte)
            MOSI_HI;
        else
            MOSI_LO;
        // clock the bits with a rising edge
        CLK_HI;
        // read MISO
        if (MISO_INPORT & MISO_BIT_MASK)
            Retval |= 1;
        Mask = Mask >> 1;
        CLK_LO;
    } while (Mask);

    return Retval;

} // end xcvByte()


static void regWrite( unsigned Reg, unsigned Value)
{

    // clock is LOW as this function is entered and exited

    SELECT_L;

    // write device address (and r/w bit which is implicitly clear
    (void) xcvByte( DEVICE_BASE_ADDRESS );

    // write register address
    (void) xcvByte( Reg );

    // write value to the register
    (void) xcvByte( Value );

    DESELECT;
}

static unsigned regRead( unsigned Reg )
{
    unsigned Retval;

    // clock is LOW as this function is entered and exited

    SELECT_L;

    // write device address with the r/w bit SET
    (void) xcvByte( DEVICE_BASE_ADDRESS | REG_READ );

    // write register address
    (void) xcvByte( Reg );

    // write zeros while actaully clocking in the register contents
     Retval = xcvByte( 0 );

    DESELECT;

    return Retval;
}


// end static/local functions

// begin public/prototyped functions

void MCP23S17_if_init( void )
{
  // configure the pins for RESET, CS, MOSI and clk as outputs
  RESET_DIRPORT |= RESET_BIT_MASK;
  CS_DIRPORT    |= CS_BIT_MASK;
  MOSI_DIRPORT  |= MOSI_BIT_MASK;
  CLK_DIRPORT   |= CLK_BIT_MASK;

  // initialize CS to HI, RESET CLK and MOSI to LOW
  DESELECT;
  RESET_L;
  CLK_LO;
  MOSI_LO;

  // allow chip to run
  NORESET;

}

void MCP23S17_setDirection( unsigned Value )
{
    regWrite( IODIRA, Value >> 8);
    regWrite( IODIRB, Value & 0xFF);
}


void MCP23S17_setOutputs( unsigned Value )
{
    regWrite( OLATA, Value >> 8);
    regWrite( OLATB, Value & 0xFF);
}

unsigned MCP23S17_readInputs( void )
{
    return (unsigned)(regRead( GPIOA ) << 8) | regRead( GPIOB );
}
