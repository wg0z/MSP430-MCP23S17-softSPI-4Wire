/*
 * MCP23S17_config.h
 *
 *  Created on: Jun 30, 2017
 *      Author: JJH
 */

#ifndef MCP23S17_CONFIG_H_
#define MCP23S17_CONFIG_H_


#define MISO_DIRPORT    P1DIR
#define MISO_INPORT     P1IN
#define MISO_BIT_NUM    3
#define MISO_BIT_MASK   (1 << MISO_BIT_NUM)

#define MOSI_DIRPORT    P1DIR
#define MOSI_OUTPORT    P1OUT
#define MOSI_BIT_NUM    1
#define MOSI_BIT_MASK   (1 << MOSI_BIT_NUM)

#define CLK_DIRPORT     P1DIR
#define CLK_OUTPORT     P1OUT
#define CLK_BIT_NUM     0
#define CLK_BIT_MASK    (1 << CLK_BIT_NUM)

#define CS_DIRPORT     P1DIR
#define CS_OUTPORT     P1OUT
#define CS_BIT_NUM     2
#define CS_BIT_MASK    (1 << CS_BIT_NUM)

#define RESET_DIRPORT     P1DIR
#define RESET_OUTPORT     P1OUT
#define RESET_BIT_NUM     4
#define RESET_BIT_MASK    (1 << RESET_BIT_NUM)


#endif /* MCP23S17_CONFIG_H_ */
