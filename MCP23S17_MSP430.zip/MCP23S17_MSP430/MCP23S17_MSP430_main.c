//***************************************************************************************
//
// MCP23S17_MSP430_main.c
//
//***************************************************************************************

#include <msp430.h>

#include "MCP23S17_prototypes.h"

volatile unsigned int cnt;    // volatile to prevent optimization

unsigned Inputs;

void main(void)
{

    WDTCTL = WDTPW | WDTHOLD;		// Stop watchdog timer

	MCP23S17_if_init();

	// set all 16 bits as OUTPUTS and TRUE
	// a 0 bit in IODIRx means OUTPUT
	MCP23S17_setDirection( 0 );
	MCP23S17_setOutputs( 0xFFFF );


	// infinite loop
	for(;;)
	{

	    Inputs = MCP23S17_readInputs();

		cnt = 10000;					// SW Delay
		do
		{
		  cnt--;
		} while ( cnt );

	} // end for()

} // end main()
