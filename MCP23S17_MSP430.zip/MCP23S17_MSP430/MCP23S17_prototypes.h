/*
 * MCP23S17_prototypes.h
 *
 *  Created on: Jun 30, 2017
 *      Author: JJH
 */

#ifndef MCP23S17_PROTOTYPES_H_
#define MCP23S17_PROTOTYPES_H_


void MCP23S17_if_init( void );

void MCP23S17_setDirection( unsigned Value );
void MCP23S17_setOutputs( unsigned Value );
unsigned MCP23S17_readInputs( void );

#endif /* MCP23S17_PROTOTYPES_H_ */
