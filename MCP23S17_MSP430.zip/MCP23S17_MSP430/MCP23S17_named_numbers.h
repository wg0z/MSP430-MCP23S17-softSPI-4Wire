/*
 * MCP23S17_named_numbers.h
 *
 *  Created on: Jul 30, 2017
 *      Author: JJH
 */

#ifndef MCP23S17_NAMED_NUMBERS_H_
#define MCP23S17_NAMED_NUMBERS_H_

#define DEVICE_BASE_ADDRESS 0x40

#define REG_READ 1

#define IODIRA  0
#define IODIRB  1
#define GPIOA   0x12
#define GPIOB   0x13
#define OLATA   0x14
#define OLATB   0x15


#endif /* MCP23S17_NAMED_NUMBERS_H_ */
